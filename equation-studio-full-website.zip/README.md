# Equation Studio — AI Math Tutor

A responsive educational web app for differentiated learning in linear equations.

## Features
- Three learning levels: Foundation, Standard, Advanced
- AI-generated equation, hint, solution steps, and explanation via Gemini
- Answer checking and hint/solution reveal controls
- Sample practice questions if the AI backend is not configured, so the interface can be explored
- Responsive layout for phones, tablets, and laptops

## Technology
- HTML, CSS, JavaScript
- Netlify Functions for server-side API calls
- Google Gemini API

## Deploy on Netlify
1. Create a public GitHub repository and upload all project files, preserving the `netlify/functions` folder.
2. Sign in at https://app.netlify.com/ and choose **Add new project / Import an existing project**.
3. Connect GitHub and select this repository. The publish directory is `.`; the `netlify.toml` file configures the functions folder.
4. In the Netlify site settings, add an environment variable named `GEMINI_API_KEY`. Its value should be your Gemini API key.
5. Redeploy the site after adding the environment variable.
6. Open the live URL and test each level, answer checking, hints, and solution display.

## Security
Never commit your API key to GitHub or put it in browser-side code. Keep it in Netlify environment variables.

## Testing
Use the sample problems to check the UI. For live AI output, verify each generated equation manually and substitute the proposed answer into both sides. AI can make mistakes.

## Academic use
Adapt this starter, understand each part, test it, and write your own final report and reflections according to your course requirements.
