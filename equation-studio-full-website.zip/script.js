const levelButtons = [...document.querySelectorAll(".level-card")];
const generateButton = document.querySelector("#generate-btn");
const statusBox = document.querySelector("#status");
const problemContent = document.querySelector("#problem-content");
const problemText = document.querySelector("#problem");
const levelBadge = document.querySelector("#level-badge");
const answerInput = document.querySelector("#answer-input");
const feedback = document.querySelector("#feedback");
const hintBox = document.querySelector("#hint-box");
const hintText = document.querySelector("#hint-text");
const solutionBox = document.querySelector("#solution-box");
const stepsList = document.querySelector("#steps-list");
const finalAnswer = document.querySelector("#final-answer");
const explanation = document.querySelector("#explanation");

let selectedLevel = "Foundation";
let currentProblem = null;

const demoProblems = {
  Foundation: [
    { problem: "x + 3 = 7", correctAnswer: 4, hint: "Get x by itself. What happens if you subtract 3 from both sides?", steps: ["Subtract 3 from both sides: x + 3 − 3 = 7 − 3.", "Simplify: x = 4."], explanation: "Both sides stay balanced when we do the same operation to each side." },
    { problem: "2x = 12", correctAnswer: 6, hint: "x is multiplied by 2. Which operation undoes multiplication?", steps: ["Divide both sides by 2: 2x ÷ 2 = 12 ÷ 2.", "Simplify: x = 6."], explanation: "Division by 2 undoes multiplication by 2." }
  ],
  Standard: [
    { problem: "3x + 5 = 20", correctAnswer: 5, hint: "First remove the +5 from the left side. Then undo multiplication by 3.", steps: ["Subtract 5 from both sides: 3x = 15.", "Divide both sides by 3: x = 5."], explanation: "Undo addition first, then multiplication, using the same operation on both sides." },
    { problem: "4x − 7 = 13", correctAnswer: 5, hint: "Add 7 to both sides first, then divide by 4.", steps: ["Add 7 to both sides: 4x = 20.", "Divide both sides by 4: x = 5."], explanation: "The inverse operations isolate x without changing the equality." }
  ],
  Advanced: [
    { problem: "3(2x − 1) = 2x + 13", correctAnswer: 4, hint: "Expand the brackets, then collect x terms on one side and constants on the other.", steps: ["Expand: 6x − 3 = 2x + 13.", "Subtract 2x from both sides: 4x − 3 = 13.", "Add 3 to both sides: 4x = 16.", "Divide by 4: x = 4."], explanation: "Substituting x = 4 gives 3(8 − 1) = 21 and 8 + 13 = 21, so both sides match." },
    { problem: "5(x − 2) = 3x + 6", correctAnswer: 8, hint: "Expand 5(x − 2), then move the x terms together.", steps: ["Expand: 5x − 10 = 3x + 6.", "Subtract 3x: 2x − 10 = 6.", "Add 10: 2x = 16.", "Divide by 2: x = 8."], explanation: "When x = 8, both sides equal 30, so the solution is correct." }
  ]
};

levelButtons.forEach((button) => {
  button.addEventListener("click", () => {
    selectedLevel = button.dataset.level;
    levelButtons.forEach((item) => {
      const active = item === button;
      item.classList.toggle("is-selected", active);
      item.setAttribute("aria-pressed", String(active));
    });
    levelBadge.textContent = selectedLevel.toUpperCase();
    showStatus(`Ready for ${selectedLevel.toLowerCase()} practice. Generate a problem when you're ready.`);
  });
});

function showStatus(message) {
  statusBox.textContent = message;
  statusBox.hidden = false;
}
function validateProblem(data) {
  return data && typeof data.problem === "string" && typeof data.hint === "string" &&
    Array.isArray(data.steps) && typeof data.correctAnswer === "number" &&
    Number.isFinite(data.correctAnswer) && typeof data.explanation === "string";
}
function renderProblem(data) {
  currentProblem = data;
  problemText.textContent = data.problem;
  hintText.textContent = data.hint;
  stepsList.replaceChildren();
  data.steps.forEach((step) => {
    const li = document.createElement("li");
    li.textContent = step;
    stepsList.appendChild(li);
  });
  finalAnswer.textContent = `Answer: x = ${data.correctAnswer}`;
  explanation.textContent = data.explanation;
  answerInput.value = "";
  feedback.textContent = "";
  feedback.className = "feedback";
  hintBox.hidden = true;
  solutionBox.hidden = true;
  problemContent.hidden = false;
  showStatus("Your problem is ready. Try solving it before revealing the solution.");
}

generateButton.addEventListener("click", async () => {
  generateButton.disabled = true;
  generateButton.textContent = "Preparing your problem…";
  try {
    // Use the live AI backend on Netlify. If it is not configured (for example, in a local preview),
    // use clearly labeled sample questions so the interface can still be explored.
    let response;
    try {
      response = await fetch("/.netlify/functions/tutor", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ level: selectedLevel })
      });
    } catch (_) {
      response = null;
    }
    if (response && response.ok) {
      const data = await response.json();
      if (!validateProblem(data)) throw new Error("The AI returned an unexpected response format.");
      renderProblem(data);
    } else {
      const options = demoProblems[selectedLevel];
      const data = options[Math.floor(Math.random() * options.length)];
      renderProblem({ ...data, demoMode: true });
      showStatus("Sample mode: showing a checked practice question. Deploy with your Gemini API key to enable AI-generated problems.");
    }
  } catch (error) {
    showStatus(`${error.message} You can try again, or use the sample question mode.`);
  } finally {
    generateButton.disabled = false;
    generateButton.innerHTML = 'Generate a problem <span>✦</span>';
  }
});

document.querySelector("#hint-btn").addEventListener("click", () => {
  if (currentProblem) hintBox.hidden = !hintBox.hidden;
});
document.querySelector("#solution-btn").addEventListener("click", () => {
  if (currentProblem) solutionBox.hidden = !solutionBox.hidden;
});
function checkAnswer() {
  if (!currentProblem) return;
  const raw = answerInput.value.trim().toLowerCase().replace(/\s+/g, "").replace(/^x=/, "");
  const number = Number(raw);
  if (!raw || !Number.isFinite(number)) {
    feedback.textContent = "Enter a number, for example 4.";
    feedback.className = "feedback incorrect";
    return;
  }
  if (Math.abs(number - currentProblem.correctAnswer) < 1e-8) {
    feedback.textContent = "Correct! Great work — you solved it.";
    feedback.className = "feedback correct";
  } else {
    feedback.textContent = "Not quite yet. Try again, or use the hint for a nudge.";
    feedback.className = "feedback incorrect";
  }
}
document.querySelector("#check-btn").addEventListener("click", checkAnswer);
answerInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") checkAnswer();
});
