# Brief Report: AI for Differentiated Learning

**Project:** Equation Studio — AI Math Tutor

**Objective:** This web application supports differentiated practice with linear equations in one variable. Students select Foundation, Standard, or Advanced and receive a suitable equation, hint, step-by-step solution, and answer feedback.

**AI integration:** The front end sends the selected level to a Netlify serverless function. The function sends a structured prompt to the Gemini API and returns JSON containing the equation, hint, solution steps, numerical answer, and explanation. The API key is stored in a Netlify environment variable and is not exposed in front-end code.

**Prompt design:** The model is instructed to act as a careful mathematics tutor, follow level-specific complexity guidance, return a fixed JSON format, choose an equation with a single integer solution, solve it, and verify its answer by substitution. Foundation uses one-step equations and direct guidance; Standard uses typical school equations; Advanced uses brackets or variables on both sides.

**Differentiation:** The selected level changes the prompt and expected difficulty. The amount of scaffolding is also adapted: Foundation receives simpler language and more direct hints, Standard receives concise support, and Advanced receives multi-step reasoning.

**Testing and limitations:** Test all three levels, answer checking, hint display, and solution display. Manually solve each generated equation and substitute the answer into both sides. AI-generated content can be wrong, so human verification remains necessary.

**Live website URL:** [Add your published URL]

**Source code repository:** [Add your public GitHub URL]
