const LEVEL_INSTRUCTIONS = {
  Foundation: "Create a one-step equation such as x + 3 = 7 or 2x = 10. Use very simple language, a direct hint, and two clear solution steps.",
  Standard: "Create a typical school equation with two or three steps, such as 3x + 5 = 20. Give a helpful hint and a concise worked solution.",
  Advanced: "Create a multi-step equation with brackets or x terms on both sides. It must have one integer solution. Explain each algebraic transformation."
};

export default async (request) => {
  if (request.method !== "POST") {
    return Response.json({ error: "Use a POST request." }, { status: 405 });
  }
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    return Response.json({ error: "GEMINI_API_KEY is not configured." }, { status: 500 });
  }

  let body;
  try { body = await request.json(); }
  catch { return Response.json({ error: "The request body must be valid JSON." }, { status: 400 }); }

  const level = body?.level;
  if (!Object.hasOwn(LEVEL_INSTRUCTIONS, level)) {
    return Response.json({ error: "Choose Foundation, Standard, or Advanced." }, { status: 400 });
  }

  const prompt = `You are a careful mathematics tutor teaching linear equations in one variable.
Generate ONE original problem for level ${level}. ${LEVEL_INSTRUCTIONS[level]}
Return only valid JSON with exactly these fields:
{"problem":"equation in plain text","hint":"one helpful hint","steps":["step 1","step 2"],"correctAnswer":4,"explanation":"brief explanation"}
Requirements:
- The equation has exactly one solution and that solution is an integer.
- correctAnswer must be a JSON number.
- Solve the equation independently and verify by substitution into both sides.
- The steps must match the equation and answer exactly.
- Use plain text such as 3x + 5 = 20, no LaTeX.
- No markdown fences and no text outside the JSON.
- Do not request personal information.
`;

  try {
    const response = await fetch(
      "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent",
      {
        method: "POST",
        headers: { "Content-Type": "application/json", "x-goog-api-key": apiKey },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { responseMimeType: "application/json", temperature: 0.3 }
        })
      }
    );
    const result = await response.json();
    if (!response.ok) {
      return Response.json({ error: result?.error?.message || "The AI request failed." }, { status: 502 });
    }
    const output = result?.candidates?.[0]?.content?.parts?.[0]?.text;
    if (!output) return Response.json({ error: "The AI returned an empty response." }, { status: 502 });
    let data;
    try { data = JSON.parse(output); }
    catch { return Response.json({ error: "The AI response was not valid JSON." }, { status: 502 }); }
    if (typeof data.problem !== "string" || typeof data.hint !== "string" ||
        !Array.isArray(data.steps) || typeof data.correctAnswer !== "number" ||
        !Number.isFinite(data.correctAnswer) || typeof data.explanation !== "string") {
      return Response.json({ error: "The AI response did not match the expected format." }, { status: 502 });
    }
    return Response.json(data);
  } catch {
    return Response.json({ error: "Could not connect to the AI service. Try again." }, { status: 502 });
  }
};
